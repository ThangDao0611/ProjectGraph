
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;

import javax.swing.JOptionPane;
public class main{
    public static void main (String[] args) {
        // define edges of the graph 
    	char a,b,c,d;
    	int n = 0;
//        List<Edge> edges = Arrays.asList(new Edge(0, 1, 2),new Edge(0, 2, 4),
//                   new Edge(1, 2, 4),new Edge(2, 0, 5), new Edge(2, 1, 4),
//                   new Edge(3, 2, 3), new Edge(4, 5, 1),new Edge(5, 4, 3));
    	List<Edge> edges = new ArrayList<Edge>();  //copy
//    	edges.add(new Edge(1,2));
//    	edges.add(new Edge(2,3));
//    	edges.add(new Edge(2,4));
//    	edges.add(new Edge(3,4));
    	try {
    		File fi = new File("C:\\Users\\ABC\\eclipse-workspace\\ProjectOOP\\src\\file.txt");
    		Scanner sc = new Scanner(fi);
    		while(sc.hasNextLine()) {
    			String str = sc.nextLine();
    			str = str.replaceAll("\\s+", "");
    			for(int i = 0; i < str.length() - 1; i++) {
    				c = str.charAt(i);
    				d = str.charAt(i+1);
    				edges.add(new Edge(Character.getNumericValue(c),Character.getNumericValue(d)));
    			}
    		}
    		sc.close();
    	} catch (FileNotFoundException e) {
    		JOptionPane.showMessageDialog(null, "An error occurred.");
    		e.printStackTrace();
    	}
        // call graph class Constructor to construct a graph
        Graph graph = new Graph(edges);
 
        // print the graph as an adjacency list
        //Graph.printGraph(graph);    
    	try {
    		File fi = new File("C:\\Users\\ABC\\eclipse-workspace\\ProjectOOP\\src\\file.txt");
    		Scanner sc = new Scanner(fi);
    		while(sc.hasNextLine()) {
    			String str = sc.nextLine();
    			str = str.replaceAll("\\s+", "");
    			for(int i = 0; i < str.length(); i++) {
    				a = str.charAt(i);
    				if(Character.getNumericValue(a) > n) {
    					n = Character.getNumericValue(a);
    				}
    			}
    		}	
    		sc.close();
    	} catch (FileNotFoundException e) {
    		JOptionPane.showMessageDialog(null, "An error occurred.");
    		e.printStackTrace();
    	}
    	
		try {
    		File fi = new File("C:\\Users\\ABC\\eclipse-workspace\\ProjectOOP\\src\\file.txt");
    		Scanner sc = new Scanner(fi);
    		Graph g = new Graph(n+1);
    		while(sc.hasNextLine()) {
    			String str = sc.nextLine();
    			str = str.replaceAll("\\s+", "");
    			for(int i = 0; i < str.length() - 1; i++) {
    				a = str.charAt(i);
    				b = str.charAt(i+1);
    				g.addEdge(Character.getNumericValue(a), Character.getNumericValue(b));
    			}
    		}
    		System.out.println("Following is Breadth First Traversal "+
                    "(starting from vertex 2)");
    		g.BFS(1);
    		g.traverseVertice(g);
    		sc.close();
    	} catch (FileNotFoundException e) {
    		JOptionPane.showMessageDialog(null, "An error occurred.");
    		e.printStackTrace();
    	}
		graph.traverseEdge(graph);
    }
}