public class Edge {
	//class to store edges of the weighted graph
	 int src, dest, weight;
	 Edge(int src, int dest){   //, int weight) {
	      this.src = src;
	      this.dest = dest;
	      //this.weight = weight;
	 }
}
